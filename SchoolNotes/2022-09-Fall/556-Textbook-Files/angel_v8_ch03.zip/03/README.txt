Chapter 3 programs

rotatingSquare1: Rotating square with no interaction

rotatingSquare2: Rotating Square with speed and direction of rotation controlled with buttons and menus

rotatingSquare3: Same as rotatingSquare2 with slider

square: demos position input by drawing a small colored square at each point on the display where the mouse is clicked

squarem: uses the mousedown event to allow continuous drawing of squares

triangle: Each mouse click adds another point to a triangle strip at the location of the mouse. Shows color interpolation across each triangle.

cad1: Rectangle drawing. Each pair of mouse clicks adds a new rectangle

cad2: Polygon drawing. Each mouse click adds a vertex. End a polygon with button click.
