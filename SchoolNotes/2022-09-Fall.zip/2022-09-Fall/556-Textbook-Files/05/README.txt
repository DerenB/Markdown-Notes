Chapter 5 Programs

The first four programs allow you to resize the object and the rotate and move the camera through buttons. Note that because the clipping volume is measured from the camera, it easy to clip out the entire object by moving the camera. You may also get odd views if you move the camera inside the object.

hat: Display of sombrero function using both filled triangles and line loops

hata: Display of the sombero function using line strips in two directions

ortho1: Interactive orthographic viewing of cube

perspective1: Interactive perspective viewing of cube

shadow: projective shadow of a square onto y = 0 plane with moving light

ortho2 and perspective2 use slide bars instead of buttons
