Deren Bozer
COSC-522 F22
Problem Set 2, Chapter 2

1) Draw the corresponding encoding of the digital data   0 0 1 1 0 1 0 0 using the specified modulation techniques. Assume a bit duration is 1 second. Whenever applicable, assume that the previous level ended at phase  